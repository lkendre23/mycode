<?php 
session_start();
$conn = mysqli_connect('localhost','dbo_pbs','Pb45#$67*','db_pbs')or die('unable to connect');
if(isset($_POST['submit'])){

	$username = $_POST['username'];
	$pass = $_POST['pass'];

	$query = "select * from login where username='$username' and password='$pass'  ";                            

	$result = mysqli_query($conn,$query);

    $myuser = '';

    if($rows = mysqli_num_rows($result) > 0 ){
        if($rows == 1){
        	$_SESSION['username'] = $username;
        	header('location:index.php');
        }else{
        	echo "failed";
        	header('location:login.php');
        }
    }


}


?>